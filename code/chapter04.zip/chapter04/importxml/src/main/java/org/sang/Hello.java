package org.sang;

/**
 * Created by sang on 2018/7/13.
 */
public class Hello {
    public String sayHello(String name) {
        return "hello " + name;
    }
}
