package org.sang;

import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Created by sang on 2018/7/15.
 */
public class MyWebMvcConfig implements WebMvcConfigurer {

}
