package org.sang;

import org.sang.jar.HelloController;

public class Main {
    public static void main(String[] args) {
        org.sang.jar.HelloController helloController = new org.sang.jar.HelloController();
    }
}
